import { Tool, ToolInput, ToolOutput } from "@openclaw/sdk";
import type { HypothesisResult, ModelDesignResult } from "./types.js";

interface ModelInput extends ToolInput {
  topic: string;
  hypotheses: HypothesisResult;
}

function buildStataCode(y: string, x: string, controls: string[]): string {
  const ctrl = controls.join(" ");
  return [
    "* Baseline regression",
    `reghdfe ${y} ${x} ${ctrl}, absorb(firm year) vce(cluster firm)`,
    "",
    "* Robustness examples",
    `winsor2 ${y} ${x} ${ctrl}, replace cuts(1 99)`,
    `reghdfe ${y} ${x} ${ctrl}, absorb(firm year) vce(cluster industry)`,
    "",
    "* Heterogeneity",
    `reghdfe ${y} c.${x}##i.high_group ${ctrl}, absorb(firm year) vce(cluster firm)`
  ].join("\n");
}

function buildPythonCode(y: string, x: string, controls: string[]): string {
  const rhs = [x, ...controls].join(" + ");
  return [
    "import statsmodels.formula.api as smf",
    `model = smf.ols('${y} ~ ${rhs} + C(firm) + C(year)', data=df).fit(cov_type='cluster', cov_kwds={'groups': df['firm']})`,
    "print(model.summary())"
  ].join("\n");
}

export const designModel: Tool<ModelInput, ModelDesignResult> = {
  name: "design_model",
  description: "Design econometric models, robustness, heterogeneity, and endogeneity strategies.",
  parameters: {
    type: "object",
    properties: {
      topic: { type: "string" },
      hypotheses: { type: "object" }
    },
    required: ["topic", "hypotheses"]
  },
  async execute(input: ModelInput): Promise<ToolOutput<ModelDesignResult>> {
    try {
      const dependentVariable = "y_outcome";
      const independentVariable = "x_core";
      const controls = ["size", "age", "leverage", "roa", "cashflow", "board", "ownership"];
      const baselineModel = `${dependentVariable}_{it} = α + β ${independentVariable}_{it} + γ Controls_{it} + μ_i + λ_t + ε_{it}`;
      const robustness = [
        "替换被解释变量测量口径",
        "替换核心解释变量测量口径",
        "缩尾处理并调整聚类层级",
        "滞后一期至三期解释变量"
      ];
      const heterogeneity = [
        "按企业规模分组",
        "按所有制分组",
        "按行业技术水平或地区市场化程度分组"
      ];
      const endogeneity = [
        "工具变量法（IV / 2SLS）",
        "倾向得分匹配 + DID / FE",
        "事件冲击或政策冲击识别",
        "Heckman 两阶段或动态面板 GMM"
      ];
      return {
        success: true,
        data: {
          dependentVariable,
          independentVariable,
          controls,
          baselineModel,
          robustness,
          heterogeneity,
          endogeneity,
          stataCode: buildStataCode(dependentVariable, independentVariable, controls),
          pythonCode: buildPythonCode(dependentVariable, independentVariable, controls)
        }
      };
    } catch (error) {
      return { success: false, error: error instanceof Error ? error.message : String(error) };
    }
  }
};
