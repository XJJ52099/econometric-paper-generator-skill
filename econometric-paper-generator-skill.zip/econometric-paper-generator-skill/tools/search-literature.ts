import { Tool, ToolInput, ToolOutput } from "@openclaw/sdk";
import { fetchJson, fetchText, guessMethods, normalizeText, parseArxivXml, scorePaper } from "./utils.js";
import type { PaperRecord, SearchOptions } from "./types.js";

interface SearchInput extends ToolInput, SearchOptions {}

interface SemanticScholarResponse {
  data?: Array<{
    title?: string;
    year?: number;
    abstract?: string;
    venue?: string;
    url?: string;
    externalIds?: { DOI?: string };
    citationCount?: number;
    authors?: Array<{ name?: string }>;
  }>;
}

interface PubMedSearchResponse { esearchresult: { idlist: string[] } }
interface PubMedSummaryResponse {
  result: Record<string, {
    uid: string;
    title?: string;
    pubdate?: string;
    source?: string;
    authors?: Array<{ name?: string }>;
    articleids?: Array<{ idtype?: string; value?: string }>;
  }> & { uids?: string[] };
}

export const searchLiterature: Tool<SearchInput, PaperRecord[]> = {
  name: "search_literature",
  description: "Search papers from Semantic Scholar, PubMed, and arXiv and return normalized records.",
  parameters: {
    type: "object",
    properties: {
      topic: { type: "string", description: "Research topic" },
      years: { type: "number", description: "Lookback years" },
      sources: { type: "array", items: { type: "string" }, description: "semantic,pubmed,arxiv" },
      maxPapers: { type: "number", description: "Maximum number of papers" },
      lang: { type: "string", enum: ["zh", "en"] }
    },
    required: ["topic", "years", "sources", "maxPapers", "lang"]
  },
  async execute(input: SearchInput): Promise<ToolOutput<PaperRecord[]>> {
    try {
      const results: PaperRecord[] = [];
      const yearFloor = new Date().getFullYear() - input.years;

      if (input.sources.includes("semantic")) {
        const apiKey = process.env.SEMANTIC_SCHOLAR_API_KEY;
        const limit = Math.min(input.maxPapers, 20);
        const url = `https://api.semanticscholar.org/graph/v1/paper/search?query=${encodeURIComponent(input.topic)}&limit=${limit}&fields=title,year,abstract,venue,url,authors,citationCount,externalIds`;
        const data = await fetchJson<SemanticScholarResponse>(url, {
          headers: apiKey ? { "x-api-key": apiKey } : undefined
        });
        for (const item of data.data ?? []) {
          if (item.year && item.year < yearFloor) continue;
          const record: PaperRecord = {
            source: "Semantic Scholar",
            title: normalizeText(item.title ?? ""),
            authors: (item.authors ?? []).map(a => a.name ?? "").filter(Boolean),
            year: item.year ?? null,
            venue: item.venue ?? "",
            abstract: normalizeText(item.abstract ?? ""),
            keywords: [],
            citations: item.citationCount ?? null,
            doi: item.externalIds?.DOI ?? "",
            url: item.url ?? "",
            methods: guessMethods(item.abstract ?? "")
          };
          record.mainFindings = record.abstract ? record.abstract.slice(0, 240) : "";
          results.push(record);
        }
      }

      if (input.sources.includes("pubmed")) {
        const apiKey = process.env.NCBI_API_KEY;
        const term = `${input.topic} AND (${yearFloor}[PDAT]:3000[PDAT])`;
        const searchUrl = `https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?db=pubmed&retmode=json&retmax=${Math.min(input.maxPapers, 20)}&term=${encodeURIComponent(term)}${apiKey ? `&api_key=${apiKey}` : ""}`;
        const search = await fetchJson<PubMedSearchResponse>(searchUrl);
        const ids = search.esearchresult.idlist;
        if (ids.length > 0) {
          const summaryUrl = `https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi?db=pubmed&retmode=json&id=${ids.join(",")}${apiKey ? `&api_key=${apiKey}` : ""}`;
          const summary = await fetchJson<PubMedSummaryResponse>(summaryUrl);
          for (const id of ids) {
            const item = summary.result[id];
            if (!item) continue;
            const year = Number.parseInt(item.pubdate?.slice(0, 4) ?? "", 10) || null;
            const doi = item.articleids?.find(a => a.idtype === "doi")?.value ?? "";
            results.push({
              source: "PubMed",
              title: normalizeText(item.title ?? ""),
              authors: (item.authors ?? []).map(a => a.name ?? "").filter(Boolean),
              year,
              venue: item.source ?? "",
              abstract: "",
              keywords: [],
              citations: null,
              doi,
              url: `https://pubmed.ncbi.nlm.nih.gov/${id}/`,
              methods: []
            });
          }
        }
      }

      if (input.sources.includes("arxiv")) {
        const query = `all:${input.topic.replace(/\s+/g, "+")}`;
        const url = `http://export.arxiv.org/api/query?search_query=${encodeURIComponent(query)}&start=0&max_results=${Math.min(input.maxPapers, 20)}&sortBy=submittedDate&sortOrder=descending`;
        const xml = await fetchText(url);
        const parsed = parseArxivXml(xml);
        const entries = parsed.feed?.entry ? (Array.isArray(parsed.feed.entry) ? parsed.feed.entry : [parsed.feed.entry]) : [];
        for (const item of entries) {
          const published = item.published ? new Date(item.published).getFullYear() : null;
          if (published && published < yearFloor) continue;
          const links = Array.isArray(item.link) ? item.link : [item.link].filter(Boolean);
          const htmlUrl = links.find((l: any) => l?.["@_type"] === "text/html")?.["@_href"] ?? item.id ?? "";
          const pdfUrl = links.find((l: any) => l?.["@_title"] === "pdf")?.["@_href"];
          const authors = Array.isArray(item.author) ? item.author : [item.author].filter(Boolean);
          const abs = normalizeText(item.summary ?? "");
          results.push({
            source: "arXiv",
            title: normalizeText(item.title ?? ""),
            authors: authors.map((a: any) => a.name).filter(Boolean),
            year: published,
            venue: "arXiv",
            abstract: abs,
            keywords: [],
            citations: null,
            doi: "",
            url: htmlUrl,
            pdfUrl,
            methods: guessMethods(abs),
            mainFindings: abs.slice(0, 240)
          });
        }
      }

      for (const paper of results) {
        paper.relevanceScore = scorePaper(input.topic, paper);
        if (!paper.methods || paper.methods.length === 0) {
          paper.methods = guessMethods(`${paper.title} ${paper.abstract}`);
        }
      }

      results.sort((a, b) => (b.relevanceScore ?? 0) - (a.relevanceScore ?? 0));
      return { success: true, data: results.slice(0, input.maxPapers) };
    } catch (error) {
      return { success: false, error: error instanceof Error ? error.message : String(error) };
    }
  }
};
