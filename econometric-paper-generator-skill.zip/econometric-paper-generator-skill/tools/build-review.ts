import { Tool, ToolInput, ToolOutput } from "@openclaw/sdk";
import type { PaperRecord, ReviewResult } from "./types.js";

interface ReviewInput extends ToolInput {
  topic: string;
  papers: PaperRecord[];
  lang: "zh" | "en";
}

function classifyStreams(papers: PaperRecord[]): Array<{ name: string; description: string; papers: string[] }> {
  const buckets = new Map<string, string[]>();
  for (const paper of papers) {
    const methods = paper.methods ?? [];
    const key = methods[0] ?? "一般经验研究";
    const current = buckets.get(key) ?? [];
    current.push(paper.title);
    buckets.set(key, current);
  }
  return [...buckets.entries()].map(([name, titles]) => ({
    name,
    description: `该分支主要使用${name}等方法分析相关议题，关注不同样本和识别策略下的经验差异。`,
    papers: titles.slice(0, 6)
  }));
}

export const buildReview: Tool<ReviewInput, ReviewResult> = {
  name: "build_review",
  description: "Build a structured literature review summary from normalized paper records.",
  parameters: {
    type: "object",
    properties: {
      topic: { type: "string" },
      papers: { type: "array", items: { type: "object" } },
      lang: { type: "string", enum: ["zh", "en"] }
    },
    required: ["topic", "papers", "lang"]
  },
  async execute(input: ReviewInput): Promise<ToolOutput<ReviewResult>> {
    try {
      const top = input.papers.slice(0, 12);
      const streams = classifyStreams(top);
      const summary = `围绕“${input.topic}”的现有研究主要从影响效应、作用机制与识别策略三个层面展开。近年文献更加重视因果识别、异质性分析与机制检验，但关于外部情境差异、变量测量统一性与长期效应的讨论仍不充分。`;
      const gaps = [
        "现有研究对长期动态效应关注不足。",
        "不同制度环境或行业情境下的结论差异仍缺乏系统比较。",
        "对中介机制、调节机制与非线性关系的识别仍可深化。"
      ];
      const controversies = [
        "核心解释变量的测量口径并不统一，导致结论可比性受限。",
        "不同识别策略对因果推断强度影响较大。",
        "样本选择偏差与反向因果问题仍是高频争议。"
      ];
      return { success: true, data: { summary, streams, gaps, controversies } };
    } catch (error) {
      return { success: false, error: error instanceof Error ? error.message : String(error) };
    }
  }
};
