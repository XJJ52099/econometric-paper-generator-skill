export interface SearchOptions {
  topic: string;
  years: number;
  sources: string[];
  maxPapers: number;
  lang: "zh" | "en";
}

export interface PaperRecord {
  source: string;
  title: string;
  authors: string[];
  year: number | null;
  venue: string;
  abstract: string;
  keywords: string[];
  citations: number | null;
  doi: string;
  url: string;
  pdfUrl?: string;
  relevanceScore?: number;
  methods?: string[];
  mainFindings?: string;
  contribution?: string;
  limitations?: string;
}

export interface ReviewResult {
  summary: string;
  streams: Array<{ name: string; description: string; papers: string[] }>;
  gaps: string[];
  controversies: string[];
}

export interface HypothesisResult {
  researchQuestion: string;
  mechanisms: string[];
  hypotheses: string[];
}

export interface ModelDesignResult {
  dependentVariable: string;
  independentVariable: string;
  controls: string[];
  baselineModel: string;
  robustness: string[];
  heterogeneity: string[];
  endogeneity: string[];
  stataCode: string;
  pythonCode: string;
}

export interface PaperStructure {
  title: string;
  abstract: string;
  introduction: string;
  literatureReview: string;
  theoreticalAnalysis: string;
  researchDesign: string;
  expectedResults: string;
  conclusion: string;
}

export interface PipelineOutput {
  topic: string;
  topicSlug: string;
  papers: PaperRecord[];
  review: ReviewResult;
  hypotheses: HypothesisResult;
  modelDesign: ModelDesignResult;
  structure: PaperStructure;
  outputDir: string;
}
