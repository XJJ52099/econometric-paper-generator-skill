import path from "node:path";
import { searchLiterature } from "./search-literature.js";
import { extractLiterature } from "./extract-literature.js";
import { buildReview } from "./build-review.js";
import { generateHypothesis } from "./generate-hypothesis.js";
import { designModel } from "./design-model.js";
import { buildPaperStructure } from "./build-paper-structure.js";
import { writePaper } from "./write-paper.js";
import { exportFiles } from "./export-files.js";
import { ensureDir, slugify } from "./utils.js";

function arg(name: string, fallback?: string): string | undefined {
  const index = process.argv.findIndex((item) => item === `--${name}`);
  return index >= 0 ? process.argv[index + 1] : fallback;
}

async function main(): Promise<void> {
  const topic = arg("topic");
  if (!topic) {
    throw new Error("Missing --topic");
  }
  const years = Number.parseInt(arg("years", process.env.YEARS ?? "5")!, 10);
  const maxPapers = Number.parseInt(arg("maxPapers", process.env.MAX_PAPERS ?? "30")!, 10);
  const lang = (arg("lang", (process.env.LANG as "zh" | "en") ?? "zh") as "zh" | "en");
  const sources = (arg("sources", "semantic,pubmed,arxiv") ?? "semantic,pubmed,arxiv").split(",").map(s => s.trim()).filter(Boolean);

  const baseDir = path.resolve(path.dirname(new URL(import.meta.url).pathname), "..");
  const outputRoot = path.resolve(process.cwd(), process.env.OUTPUT_DIR ?? "workspace/econometric-paper-generator");
  const topicSlug = slugify(topic);
  const outputDir = path.join(outputRoot, topicSlug);
  await ensureDir(outputDir);

  const searched = await searchLiterature.execute({ topic, years, sources, maxPapers, lang });
  if (!searched.success || !searched.data) throw new Error(searched.error ?? "search failed");

  const extracted = await extractLiterature.execute({ papers: searched.data });
  if (!extracted.success || !extracted.data) throw new Error(extracted.error ?? "extract failed");

  const review = await buildReview.execute({ topic, papers: extracted.data, lang });
  if (!review.success || !review.data) throw new Error(review.error ?? "review failed");

  const hypotheses = await generateHypothesis.execute({ topic, review: review.data });
  if (!hypotheses.success || !hypotheses.data) throw new Error(hypotheses.error ?? "hypothesis failed");

  const model = await designModel.execute({ topic, hypotheses: hypotheses.data });
  if (!model.success || !model.data) throw new Error(model.error ?? "model failed");

  const structure = await buildPaperStructure.execute({ topic, review: review.data, hypotheses: hypotheses.data, modelDesign: model.data });
  if (!structure.success || !structure.data) throw new Error(structure.error ?? "structure failed");

  const exported = await exportFiles.execute({ outputDir, papers: extracted.data });
  if (!exported.success || !exported.data) throw new Error(exported.error ?? "export failed");

  const written = await writePaper.execute({
    baseDir,
    outputDir,
    topic,
    papers: extracted.data,
    review: review.data,
    hypotheses: hypotheses.data,
    modelDesign: model.data,
    structure: structure.data
  });
  if (!written.success || !written.data) throw new Error(written.error ?? "write failed");

  console.log(JSON.stringify({
    topic,
    outputDir,
    literatureMatrix: exported.data.literatureMatrixPath,
    json: exported.data.jsonPath,
    ...written.data
  }, null, 2));
}

main().catch((error) => {
  console.error(error instanceof Error ? error.message : String(error));
  process.exit(1);
});
