import { Tool, ToolInput, ToolOutput } from "@openclaw/sdk";
import fs from "node:fs/promises";
import path from "node:path";
import type { HypothesisResult, ModelDesignResult, PaperRecord, PaperStructure, ReviewResult } from "./types.js";
import { readTemplate } from "./utils.js";

interface WriteInput extends ToolInput {
  baseDir: string;
  outputDir: string;
  topic: string;
  papers: PaperRecord[];
  review: ReviewResult;
  hypotheses: HypothesisResult;
  modelDesign: ModelDesignResult;
  structure: PaperStructure;
}

interface WriteOutput {
  paperDraftPath: string;
  structurePath: string;
  hypothesesPath: string;
  modelDesignPath: string;
}

export const writePaper: Tool<WriteInput, WriteOutput> = {
  name: "write_paper",
  description: "Write the econometric paper draft and supporting markdown files.",
  parameters: {
    type: "object",
    properties: {
      baseDir: { type: "string" },
      outputDir: { type: "string" },
      topic: { type: "string" },
      papers: { type: "array", items: { type: "object" } },
      review: { type: "object" },
      hypotheses: { type: "object" },
      modelDesign: { type: "object" },
      structure: { type: "object" }
    },
    required: ["baseDir", "outputDir", "topic", "papers", "review", "hypotheses", "modelDesign", "structure"]
  },
  async execute(input: WriteInput): Promise<ToolOutput<WriteOutput>> {
    try {
      const paperTemplate = await readTemplate(input.baseDir, "paper-template.md");
      const paper = paperTemplate
        .replace("{title}", input.structure.title)
        .replace("{abstract}", input.structure.abstract)
        .replace("{introduction}", input.structure.introduction)
        .replace("{review}", input.structure.literatureReview)
        .replace("{hypotheses}", input.structure.theoreticalAnalysis)
        .replace("{design}", input.structure.researchDesign)
        .replace("{expected_results}", input.structure.expectedResults)
        .replace("{conclusion}", input.structure.conclusion)
        + "\n\n## 参考文献线索\n"
        + input.papers.slice(0, 20).map((p, idx) => `${idx + 1}. ${p.authors.slice(0, 3).join(", ")} (${p.year ?? "n.d."}). ${p.title}. ${p.venue}. ${p.url}`).join("\n");

      const structureMd = [
        `# ${input.structure.title}`,
        "",
        "## 摘要",
        input.structure.abstract,
        "",
        "## 1 引言",
        input.structure.introduction,
        "",
        "## 2 文献综述",
        input.structure.literatureReview,
        "",
        "## 3 理论分析与研究假设",
        input.structure.theoreticalAnalysis,
        "",
        "## 4 研究设计",
        input.structure.researchDesign,
        "",
        "## 5 预期结果与进一步分析",
        input.structure.expectedResults,
        "",
        "## 6 结论与启示",
        input.structure.conclusion
      ].join("\n");

      const hypothesesMd = [
        "# 理论机制与研究假设",
        "",
        "## 研究问题",
        input.hypotheses.researchQuestion,
        "",
        "## 理论机制",
        ...input.hypotheses.mechanisms.map(item => `- ${item}`),
        "",
        "## 研究假设",
        ...input.hypotheses.hypotheses.map(item => `- ${item}`)
      ].join("\n");

      const modelMd = [
        "# 计量模型设计",
        "",
        `- 被解释变量：${input.modelDesign.dependentVariable}`,
        `- 核心解释变量：${input.modelDesign.independentVariable}`,
        `- 控制变量：${input.modelDesign.controls.join("、")}`,
        "",
        "## 基准模型",
        input.modelDesign.baselineModel,
        "",
        "## 稳健性检验",
        ...input.modelDesign.robustness.map(item => `- ${item}`),
        "",
        "## 异质性分析",
        ...input.modelDesign.heterogeneity.map(item => `- ${item}`),
        "",
        "## 内生性处理",
        ...input.modelDesign.endogeneity.map(item => `- ${item}`),
        "",
        "## Stata 代码",
        "```stata",
        input.modelDesign.stataCode,
        "```",
        "",
        "## Python 代码",
        "```python",
        input.modelDesign.pythonCode,
        "```"
      ].join("\n");

      const paperDraftPath = path.join(input.outputDir, "paper-draft.md");
      const structurePath = path.join(input.outputDir, "paper-structure.md");
      const hypothesesPath = path.join(input.outputDir, "hypotheses.md");
      const modelDesignPath = path.join(input.outputDir, "model-design.md");

      await fs.writeFile(paperDraftPath, paper, "utf8");
      await fs.writeFile(structurePath, structureMd, "utf8");
      await fs.writeFile(hypothesesPath, hypothesesMd, "utf8");
      await fs.writeFile(modelDesignPath, modelMd, "utf8");

      return { success: true, data: { paperDraftPath, structurePath, hypothesesPath, modelDesignPath } };
    } catch (error) {
      return { success: false, error: error instanceof Error ? error.message : String(error) };
    }
  }
};
