import { Tool, ToolInput, ToolOutput } from "@openclaw/sdk";
import { deduplicatePapers, summarizeFinding } from "./utils.js";
import type { PaperRecord } from "./types.js";

interface ExtractInput extends ToolInput {
  papers: PaperRecord[];
}

export const extractLiterature: Tool<ExtractInput, PaperRecord[]> = {
  name: "extract_literature",
  description: "Deduplicate papers and enrich them with heuristic findings, contribution, and limitations.",
  parameters: {
    type: "object",
    properties: {
      papers: { type: "array", items: { type: "object" } }
    },
    required: ["papers"]
  },
  async execute(input: ExtractInput): Promise<ToolOutput<PaperRecord[]>> {
    try {
      const unique = deduplicatePapers(input.papers).map((paper) => {
        const text = `${paper.title}. ${paper.abstract}`;
        const lower = text.toLowerCase();
        const contribution = lower.includes("contribute") || lower.includes("novel")
          ? summarizeFinding(text)
          : `本文可能的贡献在于围绕“${paper.title}”提供新的经验证据或方法视角。`;
        const limitations = lower.includes("limitation")
          ? summarizeFinding(text)
          : "局限性可能包括样本范围、识别策略、外部有效性或变量测量等方面。";
        return {
          ...paper,
          mainFindings: paper.mainFindings || summarizeFinding(text),
          contribution,
          limitations
        };
      });
      return { success: true, data: unique };
    } catch (error) {
      return { success: false, error: error instanceof Error ? error.message : String(error) };
    }
  }
};
