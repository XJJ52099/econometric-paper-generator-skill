import { Tool, ToolInput, ToolOutput } from "@openclaw/sdk";
import fs from "node:fs/promises";
import path from "node:path";
import * as XLSX from "xlsx";
import type { PaperRecord } from "./types.js";

interface ExportInput extends ToolInput {
  outputDir: string;
  papers: PaperRecord[];
}

interface ExportOutput {
  literatureMatrixPath: string;
  jsonPath: string;
}

export const exportFiles: Tool<ExportInput, ExportOutput> = {
  name: "export_files",
  description: "Export literature matrix to Excel and JSON.",
  parameters: {
    type: "object",
    properties: {
      outputDir: { type: "string" },
      papers: { type: "array", items: { type: "object" } }
    },
    required: ["outputDir", "papers"]
  },
  async execute(input: ExportInput): Promise<ToolOutput<ExportOutput>> {
    try {
      const rows = input.papers.map((p) => ({
        source_db: p.source,
        title: p.title,
        authors: p.authors.join("; "),
        year: p.year,
        venue: p.venue,
        doi: p.doi,
        url: p.url,
        abstract: p.abstract,
        methods: (p.methods ?? []).join("; "),
        main_findings: p.mainFindings ?? "",
        contribution: p.contribution ?? "",
        limitations: p.limitations ?? "",
        relevance_score: p.relevanceScore ?? null
      }));
      const wb = XLSX.utils.book_new();
      const ws = XLSX.utils.json_to_sheet(rows);
      XLSX.utils.book_append_sheet(wb, ws, "literature_matrix");
      const literatureMatrixPath = path.join(input.outputDir, "literature-matrix.xlsx");
      XLSX.writeFile(wb, literatureMatrixPath);
      const jsonPath = path.join(input.outputDir, "literature-matrix.json");
      await fs.writeFile(jsonPath, JSON.stringify(rows, null, 2), "utf8");
      return { success: true, data: { literatureMatrixPath, jsonPath } };
    } catch (error) {
      return { success: false, error: error instanceof Error ? error.message : String(error) };
    }
  }
};
