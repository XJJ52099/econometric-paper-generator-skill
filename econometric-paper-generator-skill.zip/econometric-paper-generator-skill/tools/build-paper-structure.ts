import { Tool, ToolInput, ToolOutput } from "@openclaw/sdk";
import type { HypothesisResult, ModelDesignResult, PaperStructure, ReviewResult } from "./types.js";

interface StructureInput extends ToolInput {
  topic: string;
  review: ReviewResult;
  hypotheses: HypothesisResult;
  modelDesign: ModelDesignResult;
}

export const buildPaperStructure: Tool<StructureInput, PaperStructure> = {
  name: "build_paper_structure",
  description: "Build a structured econometric paper outline and draft sections.",
  parameters: {
    type: "object",
    properties: {
      topic: { type: "string" },
      review: { type: "object" },
      hypotheses: { type: "object" },
      modelDesign: { type: "object" }
    },
    required: ["topic", "review", "hypotheses", "modelDesign"]
  },
  async execute(input: StructureInput): Promise<ToolOutput<PaperStructure>> {
    try {
      const title = `${input.topic}：基于计量实证研究的分析框架`;
      const abstract = `本文围绕“${input.topic}”展开研究，在系统梳理近年文献的基础上，构建理论分析框架并提出可检验的研究假设。进一步，本文设计面板回归为主的计量识别方案，并提出稳健性检验、异质性分析与内生性处理路径，为后续经验研究提供完整论文草稿。`;
      const introduction = `引言部分将说明“${input.topic}”的现实背景与理论意义，并指出现有文献在研究对象、识别策略和机制识别方面的不足，从而引出本文的研究问题与边际贡献。`;
      const literatureReview = `${input.review.summary}\n\n进一步可将相关研究划分为以下脉络：${input.review.streams.map(s => s.name).join("、")}。在此基础上，本文强调现有研究在${input.review.gaps.join("、")}等方面仍存在拓展空间。`;
      const theoreticalAnalysis = `${input.hypotheses.researchQuestion}\n\n理论机制主要包括：${input.hypotheses.mechanisms.join("；")}\n\n基于此，提出研究假设：${input.hypotheses.hypotheses.join("；")}。`;
      const researchDesign = `研究设计部分拟围绕被解释变量 ${input.modelDesign.dependentVariable}、核心解释变量 ${input.modelDesign.independentVariable} 与控制变量 ${input.modelDesign.controls.join("、")} 展开，基准模型设定为：${input.modelDesign.baselineModel}。`;
      const expectedResults = `本文预计围绕基准效应、稳健性检验、异质性分析与内生性处理展开经验分析，其中稳健性检验包括：${input.modelDesign.robustness.join("；")}。`;
      const conclusion = `结论部分将总结“${input.topic}”的核心研究发现，并从企业决策、政策设计与后续研究拓展三个层面提出启示。`;
      return { success: true, data: { title, abstract, introduction, literatureReview, theoreticalAnalysis, researchDesign, expectedResults, conclusion } };
    } catch (error) {
      return { success: false, error: error instanceof Error ? error.message : String(error) };
    }
  }
};
