import fs from "node:fs/promises";
import path from "node:path";
import { XMLParser } from "fast-xml-parser";
import type { PaperRecord } from "./types.js";

export function slugify(input: string): string {
  return input
    .toLowerCase()
    .replace(/[^\p{L}\p{N}]+/gu, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 80) || "topic";
}

export async function ensureDir(dir: string): Promise<void> {
  await fs.mkdir(dir, { recursive: true });
}

export async function readTemplate(baseDir: string, name: string): Promise<string> {
  return fs.readFile(path.join(baseDir, "templates", name), "utf8");
}

export function pickTop<T>(items: T[], n: number): T[] {
  return items.slice(0, n);
}

export function normalizeText(input: string): string {
  return input.replace(/\s+/g, " ").trim();
}

export function deduplicatePapers(papers: PaperRecord[]): PaperRecord[] {
  const seen = new Map<string, PaperRecord>();
  for (const p of papers) {
    const key = (p.doi || p.title).toLowerCase().trim();
    const existing = seen.get(key);
    if (!existing) {
      seen.set(key, p);
      continue;
    }
    if ((p.citations ?? 0) > (existing.citations ?? 0)) {
      seen.set(key, p);
    }
  }
  return [...seen.values()];
}

export function scorePaper(topic: string, paper: PaperRecord): number {
  const topicTerms = topic.toLowerCase().split(/\s+/).filter(Boolean);
  const hay = `${paper.title} ${paper.abstract} ${paper.venue}`.toLowerCase();
  const overlap = topicTerms.reduce((acc, term) => acc + (hay.includes(term) ? 1 : 0), 0);
  const recency = paper.year ? Math.max(0, 10 - (new Date().getFullYear() - paper.year)) : 0;
  const citations = Math.min(20, Math.log10((paper.citations ?? 0) + 1) * 5);
  return overlap * 10 + recency + citations;
}

export function guessMethods(text: string): string[] {
  const lower = text.toLowerCase();
  const patterns: Array<[RegExp, string]> = [
    [/difference[- ]in[- ]differences|did\b/i, "双重差分"],
    [/panel regression|fixed effects|fe model/i, "面板回归"],
    [/instrumental variable|iv\b|2sls/i, "工具变量"],
    [/propensity score matching|psm/i, "倾向得分匹配"],
    [/event study/i, "事件研究法"],
    [/meta-analysis/i, "Meta分析"],
    [/structural equation|sem\b/i, "结构方程模型"],
    [/logit|probit/i, "离散选择模型"],
    [/machine learning|random forest|xgboost/i, "机器学习"],
  ];
  return patterns.filter(([r]) => r.test(lower)).map(([, label]) => label);
}

export function summarizeFinding(text: string): string {
  const normalized = normalizeText(text);
  const snippets = normalized.split(/(?<=[.!?。；;])/).slice(0, 2);
  return snippets.join(" ").slice(0, 300);
}

export async function fetchJson<T>(url: string, init?: RequestInit): Promise<T> {
  const resp = await fetch(url, init);
  if (!resp.ok) throw new Error(`HTTP ${resp.status} for ${url}`);
  return resp.json() as Promise<T>;
}

export async function fetchText(url: string, init?: RequestInit): Promise<string> {
  const resp = await fetch(url, init);
  if (!resp.ok) throw new Error(`HTTP ${resp.status} for ${url}`);
  return resp.text();
}

export function parseArxivXml(xml: string): any {
  const parser = new XMLParser({ ignoreAttributes: false });
  return parser.parse(xml);
}
