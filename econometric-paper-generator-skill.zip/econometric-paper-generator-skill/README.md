# econometric-paper-generator

一个适配 OpenClaw 的科研 Skill：输入研究主题，自动完成文献检索、文献综述整合、研究假设构建、计量模型设计与论文草稿生成。

## 目录

```text
~/.openclaw/workspace/skills/econometric-paper-generator/
├── SKILL.md
├── tools/
│   ├── types.ts
│   ├── utils.ts
│   ├── search-literature.ts
│   ├── extract-literature.ts
│   ├── build-review.ts
│   ├── generate-hypothesis.ts
│   ├── design-model.ts
│   ├── build-paper-structure.ts
│   ├── write-paper.ts
│   ├── export-files.ts
│   └── run-paper.ts
├── templates/
│   ├── paper-template.md
│   ├── hypothesis-template.md
│   └── model-template.md
└── examples/
    └── example.md
```

## 安装

```bash
cd ~/.openclaw/workspace/skills
unzip econometric-paper-generator-skill.zip
mv econometric-paper-generator-skill econometric-paper-generator
cd econometric-paper-generator
npm install
```

## 测试

```bash
npm run test:topic -- --topic "数字并购对企业创新韧性的影响" --years 5 --sources semantic,pubmed,arxiv --lang zh
```

## 说明

- 这是一个**可运行骨架 + 全流程脚手架**。
- 默认不会编造实证结果；若无真实数据，只生成“研究设计与论文草稿”。
- 文献矩阵导出为 Excel，正文导出为 Markdown。
