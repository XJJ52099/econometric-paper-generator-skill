# 计量模型设计

## 被解释变量
{y}

## 核心解释变量
{x}

## 控制变量
{controls}

## 基准模型
{baseline}

## 稳健性检验
{robustness}

## 异质性分析
{heterogeneity}

## 内生性处理
{endogeneity}
