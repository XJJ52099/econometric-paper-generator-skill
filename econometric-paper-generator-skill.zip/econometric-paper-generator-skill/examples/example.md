# Example

用户输入：

请生成一篇关于“数字并购对制造业企业创新韧性的影响”的计量实证论文草稿。

系统输出：

1. literature-matrix.xlsx
2. paper-structure.md
3. hypotheses.md
4. model-design.md
5. paper-draft.md
